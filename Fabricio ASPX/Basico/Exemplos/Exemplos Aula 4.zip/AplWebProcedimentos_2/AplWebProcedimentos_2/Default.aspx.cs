﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplWebProcedimentos_2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Somar(22, 45);
        }

        void Somar(int lngValor1, int lngValor2)
        {
            int lngResultado = 0;

            lngResultado = lngValor1 + lngValor2;

            lblResultado.Text = lngResultado.ToString();
        }
    }
}