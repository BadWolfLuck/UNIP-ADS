﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplWebFuncoes_2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblResultado.Text = Somar(25, 45).ToString();
        }

        double Somar(int lngValor1, int lngValor2)
        {
            int lngResultado = 0;

            lngResultado = lngValor1 + lngValor2;

            return lngResultado;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (ListBox1.Visible)
            {
                ListBox1.Visible = false;
            }
            else
            {
                ListBox1.Visible = false;
            }
        }
    }
}