﻿namespace ConsoleApp
{
    public enum ETipoMetodo
    {
        Incluir = 1,
        Consultar = 2,
        Alterar = 3,
        Relatorio = 4,
        desativarAtivar = 5,
        MudarStatus = 6
    }
}
