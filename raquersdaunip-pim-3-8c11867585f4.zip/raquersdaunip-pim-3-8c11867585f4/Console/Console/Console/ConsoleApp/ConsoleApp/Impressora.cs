﻿namespace ConsoleApp
{
    public class Impressora
    {
        public string modelo { get; set; }
        public string fabricante { get; set; }

        Peca[] VetorPeca = new Peca[10];

        public void incluir()
        {
        }
        public void alterar()
        {
        }
        public void consultar()
        {
        }
        public void relatorio()
        {

        }
    }
}